import re

def sort_line(line):
  words = re.split(r'\W+', line)
  words.sort(key=lambda x: x.lower())
  return ' '.join(words)

def sort_lines(lines):
  sorted_lines = []
  for line in lines:
    sorted_lines.append(sort_line(line))
  sorted_lines.sort()
  return sorted_lines

def sort_file(input_file, output_file):
  try:
    with open(input_file, 'r', newline='') as f_in:
      content = f_in.read()
      lines = content.splitlines()
  except FileNotFoundError:
    print(f"Input file '{input_file}' not found.")
    return

  sorted_lines = sort_lines(lines)

  try:
    with open(output_file, 'w') as f_out:
      for line in sorted_lines:
        f_out.write(line + '\n')
  except Exception as e:
    print(f"An error occurred while writing to the output file: {e}")

if __name__ == '_main_':
  input_file = 'input.txt'
  output_file = 'output.txt'
  sort_file(input_file, output_file)
  print("Sentences sorted and written to", output_file)