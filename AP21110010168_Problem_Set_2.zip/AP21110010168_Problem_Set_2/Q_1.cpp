#include <iostream>
#include <vector>
using namespace std;

vector<int> solve(int N, int M, vector<pair<int, int>>& edges) {
    vector<vector<int>> adj_list(N+1);

    vector<int> degree(N+1, 0);
    vector<int> directions(M, -1);

    
    for (const auto& edge : edges) {
        int u = edge.first;
        int v = edge.second;
        adj_list[u].push_back(v);
        adj_list[v].push_back(u);
        degree[u]++;
        degree[v]++;
    }

    for (int i = 0; i < M; i++) {
        int u = edges[i].first;
        int v = edges[i].second;
        if (degree[u] % 2 == 0) {
            directions[i] = 0;
            degree[v]--;
        } else if (degree[v] % 2 == 0) {
            directions[i] = 1;
            degree[u]--;
        }
    }

    bool all_even = true;
    for (int i = 1; i <= N; i++) {
        if (degree[i] % 2 != 0) {
            all_even = false;
            break;
        }
    }

    if (all_even) {
        return directions;  
    } else {
        return {-1};  
    }
}
int main() {
    int T;
    cin >> T;  
    for (int t = 0; t < T; t++) {
        int N, M;
        cin >> N >> M;  
        vector<pair<int, int>> edges(M);  
        for (int i = 0; i < M; i++) {
            cin >> edges[i].first >> edges[i].second;
        }
        vector<int> result = solve(N, M, edges);
        if (result[0] == -1) {
            cout << -1 << endl;
        } else {
            for (int i = 0; i < M; i++) {
                cout << result[i] << " ";
            }
            cout << endl;
        }
    }

    return 0;
}