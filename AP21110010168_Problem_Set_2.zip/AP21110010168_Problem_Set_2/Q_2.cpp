#include <iostream>
#include <vector>

bool hasCycle(int node, const std::vector<std::vector<int>>& graph, std::vector<bool>& visited, std::vector<bool>& stack) {
    visited[node] = true;
    stack[node] = true;
    
    for (int neighbor : graph[node]) {
        if (!visited[neighbor]) {
            if (hasCycle(neighbor, graph, visited, stack)) {
                return true;
            }
        } else if (stack[neighbor]) {
            return true;
        }
    }
    
    stack[node] = false;
    return false;
}

bool canFinish(int tasks, std::vector<std::vector<int>>& prerequisites) {
    std::vector<std::vector<int>> graph(tasks);
    
    for (const auto& prereq : prerequisites) {
        graph[prereq[1]].push_back(prereq[0]);
    }
    
    std::vector<bool> visited(tasks, false);
    std::vector<bool> stack(tasks, false);
    
    for (int i = 0; i < tasks; i++) {
        if (!visited[i] && hasCycle(i, graph, visited, stack)) {
            return false;
        }
    }
    
    return true;
}

int main() {
    int T;
    std::cin >> T;
    for (int t = 0; t < T; t++) {
        int tasks, n;
        std::cin >> tasks >> n;
        std::vector<std::vector<int>> prerequisites;
        
        for (int i = 0; i < n; i++) {
            std::vector<int> prerequisite(2);
            std::cin >> prerequisite[0] >> prerequisite[1];
            prerequisites.push_back(prerequisite);
        }
        
        bool result = canFinish(tasks, prerequisites);
        std::cout << std::boolalpha << result << std::endl;
    }

    return 0;
}
