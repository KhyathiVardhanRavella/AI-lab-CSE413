import re

filename = 'example.txt'

char_count = 0
num_count = 0 
word_count = 0

with open(filename) as f:
  for line in f:
    char_count += len(line)
    words = line.split()
    word_count += len(words)
    nums = re.findall(r'\d+', line)
    num_count += len(nums)

print("Character Count:", char_count)  
print("Number Count:", num_count)
print("Word Count:", word_count)

