def calculate_similarity_index(file1, file2):
    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        text1 = f1.read()
        text2 = f2.read()

    words1 = text1.split()
    words2 = text2.split()

    total_words = len(words1) + len(words2)

    common_words = set(words1) & set(words2)

    similarity_index = len(common_words) / total_words

    return similarity_index


file_name1 = 'file1.txt'
file_name2 = 'file2.txt'

similarity_index = calculate_similarity_index(file_name1, file_name2)

print("Similarity Index:", similarity_index)
