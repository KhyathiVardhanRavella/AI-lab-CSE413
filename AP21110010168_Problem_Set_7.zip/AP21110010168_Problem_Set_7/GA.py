import random
import numpy as np
cities = [(0, 0), (1, 2), (3, 1), (5, 3), (6, 0)]

population_size = 100

generations = 100

mutation_rate = 0.01

def calculate_distance(city1, city2):
    x1, y1 = city1
    x2, y2 = city2
    return np.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

def calculate_total_distance(tour):
    return sum(calculate_distance(cities[tour[i]], cities[tour[(i + 1) % len(tour)]]) for i in range(len(tour)))

def generate_population(size):
    return [random.sample(range(len(cities)), len(cities)) for _ in range(size)]

def tournament_selection(population, k):
    tournament = random.sample(population, k)
    return min(tournament, key=calculate_total_distance)

def ordered_crossover(parent1, parent2):
    start = random.randint(0, len(parent1) - 1)
    end = random.randint(start, len(parent1) - 1)
    child = [-1] * len(parent1)
    child[start:end+1] = parent1[start:end+1]
    j = (end + 1) % len(parent2)
    for i in range(len(parent2)):
        if parent2[i] not in child:
            child[j] = parent2[i]
            j = (j + 1) % len(parent2)
    return child

def mutate(tour):
    if random.random() < mutation_rate:
        i, j = random.sample(range(len(tour)), 2)
        tour[i], tour[j] = tour[j], tour[i]

population = generate_population(population_size)
best_distance = float('inf')
for generation in range(generations):
    for _ in range(population_size // 2):
        parent1 = tournament_selection(population, 5)
        parent2 = tournament_selection(population, 5)
        child1 = ordered_crossover(parent1, parent2)
        child2 = ordered_crossover(parent2, parent1)
        mutate(child1)
        mutate(child2)
        population.extend([child1, child2])
    population = sorted(population, key=calculate_total_distance)[:population_size]
    current_best_distance = calculate_total_distance(population[0])
    if current_best_distance < best_distance:
        best_distance = current_best_distance
        best_tour = population[0]

print("Best tour:", best_tour)
print("Total distance:", best_distance)