def BFS(Graph, starting_node):
    visited = set()
    queue = [starting_node]
    result = []
    
    while queue:
        node = queue.pop(0)
        if node not in visited:
            result.append(node)
            visited.add(node)
            queue.extend(neighbor for neighbor in Graph[node] if neighbor not in visited)
    return result            

if __name__ == "__main__":
    Graph = {
        'A': ['B', 'C'],
        'B': ['D', 'E'],
        'C': ['F'],
        'D': ['A', 'E'],
        'E': ['F'],
        'F': [] 

    }
    starting_node = 'A'
    result_of_bfs = BFS(Graph, starting_node)
    print("The result of BFS Traversal = ", result_of_bfs)