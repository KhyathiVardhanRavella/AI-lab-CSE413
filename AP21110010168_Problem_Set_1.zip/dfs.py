def dfs(graph, start):
    visited = set()
    stack = [start]

    while stack:
        node = stack.pop()
        if node not in visited:
            print(node)
            visited.add(node)
            stack.extend(neighbour for neighbour in graph[node] if neighbour not in visited)
graph = {
    '5': ['2', '4'],
    '3': [],
    '7': [],
    '2': ['3','8'],
    '4': ['7'],
    '8': []
}

# Driver Code
print("The Result of DFS Traversal is = ")
dfs(graph, '5')