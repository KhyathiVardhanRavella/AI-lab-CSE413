from collections import deque
class Graph:
    def __init__(self, n):
        self.graph = {}
        self.M = n
        for i in range(n):
            self.graph[i] = []
    def addEdge(self, m, n):
        self.graph[m].append(n)
    def topologicalSort(self):
        in_degree = [0] * self.M
        for node in self.graph:
            for neighbor in self.graph[node]:
                in_degree[neighbor] += 1
        
        queue = deque()
        for node in range(self.M):
            if in_degree[node] == 0:
                queue.append(node)
        
        result = []
        while queue:
            node = queue.popleft()
            result.append(node)
            for neighbor in self.graph[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
        
        if len(result) != self.M:
            print("Graph has a cycle. Topological sort will not possible.")
        else:
            print("Topological sorting of the graph is:", result)
        
graph = Graph(5)
graph.addEdge(0, 1)
graph.addEdge(0, 3)
graph.addEdge(1, 2)
graph.addEdge(2, 3)
graph.addEdge(2, 4)
graph.addEdge(3, 4)
graph.topologicalSort()