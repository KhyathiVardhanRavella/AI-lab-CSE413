class Node:
    def createNode(self, val):
        node = Node()
        node.val = val
        node.left = None
        node.right = None
        return node

def is_Mirror(root1, root2):
    if root1 is None and root2 is None:
        return True
    
    if root1 is None or root2 is None or root1.val != root2.val:
        return False
    
    return is_Mirror(root1.left, root2.right) and is_Mirror(root1.right, root2.left)

def is_Symmetric(root):
    if root is None:
        return True
    
    return is_Mirror(root.left, root.right)

root = Node().createNode(1)
root.left = Node().createNode(2)
root.right = Node().createNode(2)
root.left.left = Node().createNode(3)
root.left.right = Node().createNode(4)
root.right.left = Node().createNode(4)
root.right.right = Node().createNode(3)

if is_Symmetric(root):
    print("The following tree is a Symmetric")
else:
    print("It is not symmetric")
