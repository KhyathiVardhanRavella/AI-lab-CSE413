def move(state, direction):
    new_state = [list(row) for row in state]
    empty_row, empty_col = find_empty_tile(state)

    if direction == 'Up' and empty_row > 0:
        new_state[empty_row][empty_col], new_state[empty_row - 1][empty_col] = new_state[empty_row - 1][empty_col], new_state[empty_row][empty_col]
    elif direction == 'Down' and empty_row < 2:
        new_state[empty_row][empty_col], new_state[empty_row + 1][empty_col] = new_state[empty_row + 1][empty_col], new_state[empty_row][empty_col]
    elif direction == 'Left' and empty_col > 0:
        new_state[empty_row][empty_col], new_state[empty_row][empty_col - 1] = new_state[empty_row][empty_col - 1], new_state[empty_row][empty_col]
    elif direction == 'Right' and empty_col < 2:
        new_state[empty_row][empty_col], new_state[empty_row][empty_col + 1] = new_state[empty_row][empty_col + 1], new_state[empty_row][empty_col]

    return new_state if new_state != state else None


def find_empty_tile(state):
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return i, j


def calculate_heuristic(state, goal_state):
    heuristic = 0
    for i in range(3):
        for j in range(3):
            if state[i][j] != goal_state[i][j]:
                goal_row, goal_col = divmod(state[i][j] - 1, 3)
                heuristic += abs(i - goal_row) + abs(j - goal_col)
    return heuristic


def create(initial_state, level):
    goal_state = [[1, 2, 3], [4, 5, 6], [7, 8, 0]]
    queue = [(initial_state, 0)]
    visited = set()

    while queue:
        queue.sort(key=lambda x: x[1] + calculate_heuristic(x[0], goal_state))
        current_state, current_level = queue.pop(0)

        if current_level > level:
            break

        if tuple(map(tuple, current_state)) in visited:
            continue

        visited.add(tuple(map(tuple, current_state)))

        heuristic_value = calculate_heuristic(current_state, goal_state)
        cost_value = current_level
        f_value = cost_value + heuristic_value

        print(f"Level {current_level} (f(n): {f_value}, g(n): {cost_value}, h(n): {heuristic_value}):\n")
        for row in current_state:
            print(" ".join(map(str, row)))
        print()

        if current_state == goal_state:
            print("Goal state reached!")
            break

        next_level = current_level + 1
        next_level_nodes = []
        for direction in ['Up', 'Down', 'Left', 'Right']:
            new_state = move(current_state, direction)
            if new_state is not None:
                next_level_nodes.append((new_state, next_level))

        queue.extend(next_level_nodes)

initial_state = [[1, 2, 3], [4, 5, 0], [6, 7, 8]]
level = 10
create(initial_state, level)
