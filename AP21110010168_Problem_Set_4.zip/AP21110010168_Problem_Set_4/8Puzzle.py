def Create(initial_state, level_number):
    queue = [(initial_state, 0)]
    visited = set()
    
    while queue:
        state, level = queue.pop(0)
        
        if level > level_number:
            break
        print_state(state)
        empty_tile_index = find_empty_tile(state)
        row, col = empty_tile_index // 3, empty_tile_index % 3
        
        for move in ['Up', 'Down', 'Left', 'Right']:
            new_row, new_col = row, col
            
            if move == 'Up':
                if row > 0:
                    new_row -= 1
            elif move == 'Down':
                if row < 2:
                    new_row += 1
            elif move == 'Left':
                if col > 0:
                    new_col -= 1
            elif move == 'Right':
                if col < 2:
                    new_col += 1
            
            new_state = swap_tiles(state, (row, col), (new_row, new_col))
            new_state_tuple = tuple(map(tuple, new_state))
            
            if new_state_tuple not in visited:
                queue.append((new_state, level + 1))
                visited.add(new_state_tuple)
                
def print_state(state):
    for row in state:
        print(row)
    print()
def find_empty_tile(state):
    for i in range(len(state)):
        for j in range(len(state[i])):
            if state[i][j] == 0:
                return i * 3 + j
def swap_tiles(state, pos1, pos2):
    new_state = [list(row) for row in state]
    new_state[pos1[0]][pos1[1]], new_state[pos2[0]][pos2[1]] = new_state[pos2[0]][pos2[1]], new_state[pos1[0]][pos1[1]]
    return new_state
initial_state = [[1, 2, 3], [4, 5, 6], [7, 0, 8]]
level_number = 3
Create(initial_state, level_number)